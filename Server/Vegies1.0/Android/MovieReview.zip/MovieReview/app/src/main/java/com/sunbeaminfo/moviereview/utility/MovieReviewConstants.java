package com.sunbeaminfo.moviereview.utility;

public class MovieReviewConstants {
    public static final String SHARED_PREFERENCE_FILE_NAME = "movie_review_sp";
    public static final String LOGIN_STATUS = "login_status";
    public static final String USER_ID = "id";


}
