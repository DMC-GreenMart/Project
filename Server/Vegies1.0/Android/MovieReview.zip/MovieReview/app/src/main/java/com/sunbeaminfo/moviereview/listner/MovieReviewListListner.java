package com.sunbeaminfo.moviereview.listner;

public interface MovieReviewListListner {
    public void onDeleteClicked(int id);
}
